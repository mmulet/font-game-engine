def endCharacterCommand():
  return "endchar\n"