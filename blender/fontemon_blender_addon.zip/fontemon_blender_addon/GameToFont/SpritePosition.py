class SpritePosition:
    def __init__(self, x: float, y: float) -> None:
        self.x = x
        self.y = y
