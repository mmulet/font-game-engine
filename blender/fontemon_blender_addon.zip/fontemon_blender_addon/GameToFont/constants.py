firstNodeId = "first_scene"
pixelWidth = 12
pixelHeight = 12
fontCharacterWidth = 8
fontCharacterHeight = 14
# This isn't really a value you can
# change. This is set by chrome.
# Looks like every char has a
# height of 800. Or is t set tby the 800
# in the ascent of the font? in ./hhea/ascent
commandHeight = 800