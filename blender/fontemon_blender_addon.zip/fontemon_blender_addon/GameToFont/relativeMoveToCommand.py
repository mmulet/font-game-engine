def relativeMoveToCommand(dx: float, dy: float) -> str:
  return f"{dx} {dy} rmoveto\n"