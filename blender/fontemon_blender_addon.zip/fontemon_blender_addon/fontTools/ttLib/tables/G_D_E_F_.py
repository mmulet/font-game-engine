from fontemon_blender_addon.fontTools.misc.py23 import *
from .otBase import BaseTTXConverter


class table_G_D_E_F_(BaseTTXConverter):
	pass
