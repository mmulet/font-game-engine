from fontemon_blender_addon.fontTools.misc.py23 import *
from .otBase import BaseTTXConverter


class table_G_P_O_S_(BaseTTXConverter):
	pass
