from fontemon_blender_addon.fontTools.misc.py23 import *
import sys
from fontemon_blender_addon.fontTools.mtiLib import main

if __name__ == '__main__':
	sys.exit(main())
